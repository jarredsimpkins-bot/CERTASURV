#requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$ApplyLatest,
    [switch]$Status
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'

$Root='D:\CERTARD'
$ReceiptRoot=Join-Path $Root 'receipts\reviewed-packages'
$WorkingRoot=Join-Path $Root 'staging\reviewed-packages'
$LedgerPath=Join-Path $ReceiptRoot 'APPLIED.json'
function Ensure-Dir([string]$p){if(-not(Test-Path -LiteralPath $p)){New-Item -ItemType Directory -Force -Path $p|Out-Null}}
function Write-Utf8NoBom([string]$p,[string]$t){$e=New-Object System.Text.UTF8Encoding($false);[IO.File]::WriteAllText($p,$t,$e)}
function Resolve-CertardExchange {
    $pairs=@()
    foreach($d in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)){
        $r=$d.Root
        $meshRoots=@(
            (Join-Path $r 'Shared drives\CERTASURV_PROJECT DRIVE\CERTARD_MESH'),
            (Join-Path $r 'CERTASURV_PROJECT DRIVE\CERTARD_MESH'),
            (Join-Path $r 'CERTARD_MESH')
        )
        foreach($m in $meshRoots){
            $q=Join-Path $m 'overlay\requests';$rel=Join-Path $m 'releases'
            if((Test-Path -LiteralPath $q) -and (Test-Path -LiteralPath $rel)){$pairs += [pscustomobject]@{requests=(Resolve-Path -LiteralPath $q).Path;releases=(Resolve-Path -LiteralPath $rel).Path;kind='canonical-mesh'}}
        }
        foreach($s in @((Join-Path $r 'CERTARD_STAGE'),(Join-Path $r 'My Drive\CERTARD_STAGE'),(Join-Path $r 'Shared drives\CERTARD_STAGE'))){
            if(Test-Path -LiteralPath $s){$p=(Resolve-Path -LiteralPath $s).Path;$pairs += [pscustomobject]@{requests=$p;releases=$p;kind='legacy-stage'}}
        }
    }
    foreach($s in @('D:\CERTARD_STAGE','D:\CERTARD\STAGE')){if(Test-Path -LiteralPath $s){$p=(Resolve-Path -LiteralPath $s).Path;$pairs += [pscustomobject]@{requests=$p;releases=$p;kind='local-stage'}}}
    $uniq=@($pairs|Sort-Object requests,releases -Unique)
    if($uniq.Count -gt 1){$canonical=@($uniq|Where-Object{$_.kind -eq 'canonical-mesh'});if($canonical.Count -eq 1){return $canonical[0]};if($canonical.Count -gt 1){throw 'Multiple canonical CERTARD_MESH desktop mounts found; refusing ambiguous apply.'}}
    if($uniq.Count -eq 1){return $uniq[0]}
    return $null
}

function Mirror-Receipt([string]$Path) {
    foreach($d in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)){
        foreach($r in @(
            (Join-Path $d.Root 'Shared drives\CERTASURV_PROJECT DRIVE\CERTARD_MESH\overlay\receipts\survey-msi'),
            (Join-Path $d.Root 'CERTASURV_PROJECT DRIVE\CERTARD_MESH\overlay\receipts\survey-msi')
        )){
            if(Test-Path -LiteralPath $r){try{Copy-Item -LiteralPath $Path -Destination (Join-Path $r (Split-Path -Leaf $Path)) -Force;return $r}catch{}}
        }
    }
    return ''
}

function Read-Ledger {if(-not(Test-Path -LiteralPath $LedgerPath)){return @()};try{return @([IO.File]::ReadAllText($LedgerPath)|ConvertFrom-Json)}catch{return @()}}
function Write-Ledger($rows){Write-Utf8NoBom $LedgerPath (@($rows)|ConvertTo-Json -Depth 8)}
function Safe-Child([string]$parent,[string]$child){$p=[IO.Path]::GetFullPath($parent).TrimEnd('\')+'\';$c=[IO.Path]::GetFullPath($child);if(-not $c.StartsWith($p,[StringComparison]::OrdinalIgnoreCase)){throw "Path escapes approved root: $child"};return $c}

if($env:COMPUTERNAME -ine 'MSI'){throw "Reviewed package handler is pinned to MSI; current=$env:COMPUTERNAME"}
if(-not(Test-Path -LiteralPath 'D:\')){throw 'D: is not mounted.'}
Ensure-Dir $ReceiptRoot;Ensure-Dir $WorkingRoot
$exchange=Resolve-CertardExchange
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$receiptPath=Join-Path $ReceiptRoot "reviewed-package-$stamp.json"
$ledger=@(Read-Ledger)
$candidates=@()
if($exchange){
    foreach($f in @(Get-ChildItem -LiteralPath $exchange.requests -Filter '*.request.json' -File -ErrorAction SilentlyContinue)){
        try{
            $r=[IO.File]::ReadAllText($f.FullName)|ConvertFrom-Json
            $hostMatch=($r.target_host_expected -and [string]$r.target_host_expected -ieq $env:COMPUTERNAME)
            $nodeMatch=($r.target_node -and [string]$r.target_node -ieq 'MSI')
            $authorized=([string]$r.request_status -in @('OWNER_PRESENT_AUTHORIZED','REVIEWED_AUTHORIZED'))
            $shellOk=($r.authorization -and [bool]$r.authorization.direct_shell_authorized_for_this_deployment)
            $notExpired=$true
            if($r.PSObject.Properties.Name -contains 'expires_utc' -and -not [string]::IsNullOrWhiteSpace([string]$r.expires_utc)){try{$notExpired=([datetime]::Parse([string]$r.expires_utc).ToUniversalTime() -gt (Get-Date).ToUniversalTime())}catch{$notExpired=$false}}
            if(($hostMatch -or $nodeMatch) -and $authorized -and $shellOk -and $notExpired){$created=[datetime]::MinValue;try{$created=[datetime]::Parse([string]$r.created_utc).ToUniversalTime()}catch{};$candidates += [pscustomobject]@{file=$f;request=$r;created=$created}}
        }catch{}
    }
}
$selected=$null;if($candidates.Count -gt 0){$selected=$candidates|Sort-Object created -Descending|Select-Object -First 1}
$status=[ordered]@{schema='certard.reviewed-package.status.v2';generated_at=(Get-Date).ToUniversalTime().ToString('o');computer=$env:COMPUTERNAME;exchange_kind=$(if($exchange){$exchange.kind}else{''});requests_root=$(if($exchange){$exchange.requests}else{''});releases_root=$(if($exchange){$exchange.releases}else{''});eligible_requests=$candidates.Count;selected_request=$(if($selected){$selected.file.Name}else{''});applied_count=$ledger.Count;mode=$(if($ApplyLatest){'apply'}else{'status'});result='status_only';details=@()}

if($ApplyLatest){
    try{
        if(-not $exchange){throw 'Canonical CERTARD_MESH desktop sync (or approved local fallback stage) not found.'}
        if(-not $selected){throw 'No unexpired owner/review-authorized request targets MSI.'}
        $r=$selected.request
        foreach($required in @('request_id','package_name','package_sha256','installer_relpath','installer_sha256')){if(-not($r.PSObject.Properties.Name -contains $required) -or [string]::IsNullOrWhiteSpace([string]$r.$required)){throw "Request missing $required"}}
        $reqId=[string]$r.request_id
        $already=@($ledger|Where-Object{[string]$_.request_id -eq $reqId})|Select-Object -First 1
        if($already){$status.result='already_applied';$status.details=@($already)}else{
            $package=Safe-Child $exchange.releases (Join-Path $exchange.releases ([string]$r.package_name))
            if(-not(Test-Path -LiteralPath $package)){throw "Package missing: $package"}
            $pkgHash=(Get-FileHash -Algorithm SHA256 -LiteralPath $package).Hash.ToLowerInvariant();if($pkgHash -ne ([string]$r.package_sha256).ToLowerInvariant()){throw "Package SHA256 mismatch: expected=$($r.package_sha256) actual=$pkgHash"}
            $work=Join-Path $WorkingRoot $reqId;if(Test-Path -LiteralPath $work){Remove-Item -LiteralPath $work -Recurse -Force};Ensure-Dir $work
            Expand-Archive -LiteralPath $package -DestinationPath $work -Force
            $installer=Safe-Child $work (Join-Path $work ([string]$r.installer_relpath));if(-not(Test-Path -LiteralPath $installer)){throw "Installer missing after extraction: $installer"}
            $installerHash=(Get-FileHash -Algorithm SHA256 -LiteralPath $installer).Hash.ToLowerInvariant();if($installerHash -ne ([string]$r.installer_sha256).ToLowerInvariant()){throw "Installer SHA256 mismatch: expected=$($r.installer_sha256) actual=$installerHash"}
            $stdout=Join-Path $work 'installer-output.txt';$start=(Get-Date).ToUniversalTime().ToString('o')
            & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer *>&1 | Tee-Object -FilePath $stdout
            $exit=$LASTEXITCODE;$outputHash=$(if(Test-Path -LiteralPath $stdout){(Get-FileHash -Algorithm SHA256 -LiteralPath $stdout).Hash}else{''})
            $entry=[pscustomobject]@{request_id=$reqId;request_file=$selected.file.Name;package=[string]$r.package_name;package_sha256=$pkgHash;installer_relpath=[string]$r.installer_relpath;installer_sha256=$installerHash;started_utc=$start;completed_utc=(Get-Date).ToUniversalTime().ToString('o');exit_code=[int]$exit;output_sha256=$outputHash;status=$(if($exit -eq 0){'completed'}else{'failed'})}
            $ledger += $entry;Write-Ledger $ledger;$status.result=$entry.status;$status.details=@($entry);if($exit -ne 0){throw "Reviewed installer exited $exit"}
        }
    }catch{$status.result='failed';$status.error=$_.Exception.Message}
}
Write-Utf8NoBom $receiptPath ($status|ConvertTo-Json -Depth 10);Write-Utf8NoBom (Join-Path $ReceiptRoot 'LATEST.json') ($status|ConvertTo-Json -Depth 10)
$status.mirror_root=Mirror-Receipt $receiptPath
$status|ConvertTo-Json -Depth 10
if($status.result -eq 'failed'){exit 1}
