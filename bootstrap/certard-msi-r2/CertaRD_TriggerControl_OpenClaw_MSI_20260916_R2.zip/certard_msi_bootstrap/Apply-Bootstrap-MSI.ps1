#requires -Version 5.1
[CmdletBinding()]
param()
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
if($env:COMPUTERNAME -ine 'MSI'){throw "Bootstrap pinned to MSI; current=$env:COMPUTERNAME"}
if(-not(Test-Path -LiteralPath 'D:\')){throw 'D: removable/storage drive is not mounted.'}
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$root='D:\CERTARD'
$scripts=Join-Path $root 'scripts'
$openScripts='D:\CERTARD\OPENCLAW\scripts'
$receipts=Join-Path $root 'receipts\bootstrap'
foreach($d in @($scripts,$openScripts,$receipts)){if(-not(Test-Path -LiteralPath $d)){New-Item -ItemType Directory -Force -Path $d|Out-Null}}
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$backupRoot=Join-Path $root "backups\trigger-control-$stamp";New-Item -ItemType Directory -Force -Path $backupRoot|Out-Null
$mapping=@(
    @('Repair-CertardTriggerControl.ps1',(Join-Path $scripts 'Repair-CertardTriggerControl.ps1')),
    @('Apply-CertardReviewedPackage.ps1',(Join-Path $scripts 'Apply-CertardReviewedPackage.ps1')),
    @('Install-CertardOpenClaw.ps1',(Join-Path $openScripts 'Install-CertardOpenClaw.ps1'))
)
$copied=@()
foreach($m in $mapping){$src=Join-Path $here $m[0];$dst=$m[1];if(-not(Test-Path -LiteralPath $src)){throw "Package member missing: $src"};if(Test-Path -LiteralPath $dst){Copy-Item -LiteralPath $dst -Destination (Join-Path $backupRoot ([IO.Path]::GetFileName($dst))) -Force};Copy-Item -LiteralPath $src -Destination $dst -Force;$copied += [ordered]@{path=$dst;sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $dst).Hash}}
$repair=Join-Path $scripts 'Repair-CertardTriggerControl.ps1'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $repair -ApplyDefaults -Reload
$exit=$LASTEXITCODE
$receipt=[ordered]@{schema='certard.msi.bootstrap.receipt.v1';generated_at=(Get-Date).ToUniversalTime().ToString('o');computer=$env:COMPUTERNAME;backup_root=$backupRoot;copied=$copied;registry_exit_code=[int]$exit;status=$(if($exit -eq 0){'completed'}else{'failed'})}
$enc=New-Object System.Text.UTF8Encoding($false);$path=Join-Path $receipts "bootstrap-$stamp.json";[IO.File]::WriteAllText($path,($receipt|ConvertTo-Json -Depth 8),$enc);[IO.File]::WriteAllText((Join-Path $receipts 'LATEST.json'),($receipt|ConvertTo-Json -Depth 8),$enc)
$receipt|ConvertTo-Json -Depth 8
if($exit -ne 0){exit $exit}
