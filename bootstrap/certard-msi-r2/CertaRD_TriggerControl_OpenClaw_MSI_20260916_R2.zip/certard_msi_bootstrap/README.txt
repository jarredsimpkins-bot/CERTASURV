CertaRD MSI Trigger Control + OpenClaw bootstrap — 2026-09-16

Purpose
- Fix TriggerCMD commands.json writes so they are UTF-8 without BOM.
- Back up and atomically update the existing command catalog.
- Reload the foreground TriggerCMD agent after registry changes.
- Enroll stable fixed commands for trigger refresh/status, reviewed package apply/status, and OpenClaw install/status.
- Put the OpenClaw runtime/state/workspace on D:\CERTARD\OPENCLAW.
- Keep local Ollama on 127.0.0.1:11434 and reuse an already-installed model.
- Do not pull a new Ollama model.
- Keep OpenClaw host exec/process/write/edit/browser disabled by default on MSI.

Initial bootstrap
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\certard_msi_bootstrap\Apply-Bootstrap-MSI.ps1

After bootstrap, remote reviewed package flow
1. Place one hash-bound *.zip and matching *.request.json in CERTARD_STAGE.
2. Trigger "Certa Reviewed Package Apply" on MSI.
3. Read the terminal receipt; TriggerCMD "Trigger sent" alone is not completion evidence.

OpenClaw
- Trigger "Certa OpenClaw Install" once the new command inventory is visible.
- Trigger "Certa OpenClaw Status" to write a fresh status receipt.
