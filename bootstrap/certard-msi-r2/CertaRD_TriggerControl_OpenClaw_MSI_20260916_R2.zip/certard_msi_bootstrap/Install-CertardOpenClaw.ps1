#requires -Version 5.1
[CmdletBinding()]
param([switch]$Install,[switch]$Status)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
if(-not $Install -and -not $Status){$Status=$true}
if($Install -and $Status){throw 'Choose -Install or -Status.'}
if($env:COMPUTERNAME -ine 'MSI'){throw "OpenClaw MSI package is pinned to COMPUTERNAME=MSI; current=$env:COMPUTERNAME"}
if(-not(Test-Path -LiteralPath 'D:\')){throw 'D: is not mounted. Refusing alternate destination.'}

$Root='D:\CERTARD\OPENCLAW'
$Runtime=Join-Path $Root 'runtime'
$NodeRoot=Join-Path $Runtime 'node'
$PackageRoot=Join-Path $Runtime 'package'
$State=Join-Path $Root 'state'
$Workspace=Join-Path $Root 'workspace'
$Receipts=Join-Path $Root 'receipts'
$Logs=Join-Path $Root 'logs'
$Installer=Join-Path $Root 'installer\openclaw-install.ps1'
$Version='2026.9.4'
$OfficialInstallerUrl='https://openclaw.ai/install.ps1'
function Ensure-Dir([string]$p){if(-not(Test-Path -LiteralPath $p)){New-Item -ItemType Directory -Force -Path $p|Out-Null}}
function Write-Utf8NoBom([string]$p,[string]$t){$e=New-Object System.Text.UTF8Encoding($false);[IO.File]::WriteAllText($p,$t,$e)}

function Mirror-Receipt([string]$Path) {
    foreach($d in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)){
        foreach($r in @(
            (Join-Path $d.Root 'Shared drives\CERTASURV_PROJECT DRIVE\CERTARD_MESH\overlay\receipts\survey-msi'),
            (Join-Path $d.Root 'CERTASURV_PROJECT DRIVE\CERTARD_MESH\overlay\receipts\survey-msi')
        )){
            if(Test-Path -LiteralPath $r){try{Copy-Item -LiteralPath $Path -Destination (Join-Path $r (Split-Path -Leaf $Path)) -Force;return $r}catch{}}
        }
    }
    return ''
}

function Invoke-Captured([string]$cmd,[string[]]$args){$o=@();$x=0;try{$o=@(& $cmd @args 2>&1|ForEach-Object{"$_"});$x=$LASTEXITCODE;if($null -eq $x){$x=0}}catch{$o+=$_.Exception.Message;$x=999};[ordered]@{command=$cmd;arguments=$args;exit_code=[int]$x;output=$o}}
function Set-Env {
    $env:OPENCLAW_HOME=$Root
    $env:OPENCLAW_STATE_DIR=$State
    $env:OPENCLAW_CONFIG_PATH=(Join-Path $State 'openclaw.json')
    $env:OPENCLAW_WORKSPACE_DIR=$Workspace
    $env:OLLAMA_API_KEY='ollama-local'
    $env:Path="$NodeRoot;$env:Path"
}
function Get-Ollama {
    try{
        $tags=Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 5
        $names=@($tags.models|ForEach-Object{[string]$_.name}|Where-Object{$_})
        $pick='';foreach($n in @('certard-local:latest','qwen3.5:4b')){if($names -contains $n){$pick=$n;break}};if(-not $pick -and $names.Count){$pick=$names[0]}
        return [ordered]@{reachable=$true;models=$names;selected=$pick}
    }catch{return [ordered]@{reachable=$false;models=@();selected='';error=$_.Exception.Message}}
}
function Get-OpenClawCmd {
    $c=Join-Path $PackageRoot 'node_modules\.bin\openclaw.cmd';if(Test-Path -LiteralPath $c){return $c};return ''
}
foreach($d in @($Root,$Runtime,$NodeRoot,$PackageRoot,$State,$Workspace,$Receipts,$Logs,(Split-Path -Parent $Installer))){Ensure-Dir $d}
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$receiptPath=Join-Path $Receipts "openclaw-$stamp-$(if($Install){'install'}else{'status'}).json"
$receipt=[ordered]@{schema='certard.openclaw.msi.receipt.v2';generated_at=(Get-Date).ToUniversalTime().ToString('o');computer=$env:COMPUTERNAME;mode=$(if($Install){'install'}else{'status'});root=$Root;openclaw_version=$Version;actions=@();status='running'}
try{
    Set-Env
    if($Install){
        $ollama=Get-Ollama;if(-not $ollama.reachable){throw 'Ollama is not reachable at 127.0.0.1:11434.'};if(-not $ollama.selected){throw 'No installed Ollama model found; installer will not pull one.'}
        $receipt.ollama=$ollama
        Invoke-WebRequest -UseBasicParsing -Uri $OfficialInstallerUrl -OutFile $Installer
        $ih=(Get-FileHash -Algorithm SHA256 -LiteralPath $Installer).Hash
        $receipt.actions += [ordered]@{action='download-official-openclaw-installer';url=$OfficialInstallerUrl;path=$Installer;sha256=$ih}
        $nodeExe=Join-Path $NodeRoot 'node.exe'
        if(-not(Test-Path -LiteralPath $nodeExe)){
            $r=Invoke-Captured 'powershell.exe' @('-NoProfile','-ExecutionPolicy','Bypass','-File',$Installer,'-NodeOnly','-NodePrefix',$NodeRoot)
            $receipt.actions += [ordered]@{action='install-private-node';result=$r};if($r.exit_code -ne 0){throw "Private Node install failed: $($r.exit_code)"}
        }
        $npm=Join-Path $NodeRoot 'npm.cmd';if(-not(Test-Path -LiteralPath $npm)){throw "npm.cmd missing at $npm"}
        Set-Env
        if(-not(Test-Path -LiteralPath (Join-Path $PackageRoot 'package.json'))){$r=Invoke-Captured $npm @('--prefix',$PackageRoot,'init','-y');$receipt.actions += [ordered]@{action='npm-init';result=$r}}
        $r=Invoke-Captured $npm @('--prefix',$PackageRoot,'install','--save-exact',("openclaw@"+$Version));$receipt.actions += [ordered]@{action='install-openclaw-pinned';result=$r};if($r.exit_code -ne 0){throw "npm install openclaw@$Version failed: $($r.exit_code)"}
        $oc=Get-OpenClawCmd;if(-not $oc){throw 'OpenClaw command missing after npm install.'}
        $r=Invoke-Captured $oc @('onboard','--non-interactive','--accept-risk','--skip-health','--auth-choice','ollama','--custom-base-url','http://127.0.0.1:11434','--custom-model-id',[string]$ollama.selected)
        $receipt.actions += [ordered]@{action='onboard-local-ollama';result=$r};if($r.exit_code -ne 0){throw "OpenClaw onboard failed: $($r.exit_code)"}
        $patch=@"
{
  agents: { defaults: { workspace: "$($Workspace.Replace('\','\\'))", userTimezone: "America/New_York", model: { primary: "ollama/$($ollama.selected)" } } },
  tools: {
    profile: "coding",
    allow: ["read", "sessions_list", "sessions_history", "sessions_send", "session_status", "ask_user"],
    deny: ["exec", "process", "write", "edit", "apply_patch", "browser", "nodes", "cron", "gateway"],
    fs: { workspaceOnly: true },
    sessions: { visibility: "tree" },
    elevated: { enabled: false }
  }
}
"@
        $patchPath=Join-Path $State 'certard-msi-safety.patch.json5';Write-Utf8NoBom $patchPath $patch
        foreach($args in @(@('config','patch','--file',$patchPath,'--dry-run'),@('config','patch','--file',$patchPath),@('config','validate'))){$r=Invoke-Captured $oc $args;$receipt.actions += [ordered]@{action=('openclaw '+($args -join ' '));result=$r};if($r.exit_code -ne 0){throw "OpenClaw configuration failed: $($args -join ' ')"}}
        $launcher=@"
@echo off
setlocal
set "OPENCLAW_HOME=$Root"
set "OPENCLAW_STATE_DIR=$State"
set "OPENCLAW_CONFIG_PATH=$(Join-Path $State 'openclaw.json')"
set "OPENCLAW_WORKSPACE_DIR=$Workspace"
set "OLLAMA_API_KEY=ollama-local"
set "PATH=$NodeRoot;%PATH%"
call "$PackageRoot\node_modules\.bin\openclaw.cmd" %*
"@
        Write-Utf8NoBom (Join-Path $Root 'OPENCLAW_CERTARD.cmd') $launcher
        Write-Utf8NoBom (Join-Path $State '.env') ("OLLAMA_API_KEY=ollama-local`r`n")
        $receipt.status='installed_verified_config'
    }else{$receipt.status='status'}
    Set-Env
    $oc=Get-OpenClawCmd
    $receipt.openclaw_installed=[bool]$oc
    if($oc){$receipt.version=Invoke-Captured $oc @('--version');$receipt.doctor=Invoke-Captured $oc @('doctor','--non-interactive')}
    $receipt.ollama=Get-Ollama
    $nodeExe=Join-Path $NodeRoot 'node.exe';if(Test-Path -LiteralPath $nodeExe){$receipt.node=Invoke-Captured $nodeExe @('--version')}
}catch{$receipt.status='failed';$receipt.error=$_.Exception.Message}
$receipt.completed_at=(Get-Date).ToUniversalTime().ToString('o')
Write-Utf8NoBom $receiptPath ($receipt|ConvertTo-Json -Depth 12)
Write-Utf8NoBom (Join-Path $Receipts 'LATEST.json') ($receipt|ConvertTo-Json -Depth 12)
$receipt.mirror_root=Mirror-Receipt $receiptPath
$receipt|ConvertTo-Json -Depth 12
if($receipt.status -eq 'failed'){exit 1}
