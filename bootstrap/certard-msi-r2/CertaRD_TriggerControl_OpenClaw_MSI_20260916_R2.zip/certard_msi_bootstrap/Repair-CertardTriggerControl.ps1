#requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$ApplyDefaults,
    [switch]$Reload,
    [switch]$Status
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$CertardRoot = 'D:\CERTARD'
$ScriptRoot = Join-Path $CertardRoot 'scripts'
$OpenClawScript = 'D:\CERTARD\OPENCLAW\scripts\Install-CertardOpenClaw.ps1'
$SelfPath = Join-Path $ScriptRoot 'Repair-CertardTriggerControl.ps1'
$ReviewedPackagePath = Join-Path $ScriptRoot 'Apply-CertardReviewedPackage.ps1'
$ReceiptRoot = Join-Path $CertardRoot 'receipts\triggercmd'

function Ensure-Dir([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null }
}
function Write-Utf8NoBom([string]$Path,[string]$Text) {
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path,$Text,$enc)
}

function Mirror-Receipt([string]$Path) {
    foreach($d in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)){
        foreach($r in @(
            (Join-Path $d.Root 'Shared drives\CERTASURV_PROJECT DRIVE\CERTARD_MESH\overlay\receipts\survey-msi'),
            (Join-Path $d.Root 'CERTASURV_PROJECT DRIVE\CERTARD_MESH\overlay\receipts\survey-msi')
        )){
            if(Test-Path -LiteralPath $r){try{Copy-Item -LiteralPath $Path -Destination (Join-Path $r (Split-Path -Leaf $Path)) -Force;return $r}catch{}}
        }
    }
    return ''
}

function Get-TriggerState {
    $dataDir = Join-Path $env:USERPROFILE '.TRIGGERcmdData'
    $svc = Get-Service TRIGGERcmdAgent -ErrorAction SilentlyContinue
    $procs = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '(?i)^TRIGGERcmd.*\.exe$' })
    [ordered]@{
        data_dir = $dataDir
        commands = Join-Path $dataDir 'commands.json'
        registered = ((Test-Path -LiteralPath (Join-Path $dataDir 'token.tkn')) -and (Test-Path -LiteralPath (Join-Path $dataDir 'computerid.cfg')))
        service_exists = [bool]$svc
        service_status = $(if($svc){[string]$svc.Status}else{'missing'})
        processes = @($procs | Select-Object ProcessId,Name,ExecutablePath,CreationDate)
    }
}
function Get-AgentExe {
    $p = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -ieq 'TRIGGERcmd Agent.exe' } | ForEach-Object { $_.ExecutablePath })
    $p += @(
        "$env:LOCALAPPDATA\Programs\TRIGGERcmd\TRIGGERcmd Agent.exe",
        "$env:LOCALAPPDATA\Programs\triggercmd\TRIGGERcmd Agent.exe"
    )
    foreach($x in ($p | Where-Object { $_ } | Select-Object -Unique)){if(Test-Path -LiteralPath $x){return $x}}
    return ''
}
function Restart-TriggerCmd {
    $events=@()
    $exe=Get-AgentExe
    $svc=Get-Service TRIGGERcmdAgent -ErrorAction SilentlyContinue
    if($svc -and $svc.Status -eq 'Running'){
        try{Restart-Service TRIGGERcmdAgent -Force -ErrorAction Stop;$events+='restarted-service'}catch{$events+="service-restart-failed:$($_.Exception.Message)"}
    }
    $fg=@(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -ieq 'TRIGGERcmd Agent.exe' })
    foreach($p in $fg){try{Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop;$events+="stopped-foreground:$($p.ProcessId)"}catch{$events+="foreground-stop-failed:$($p.ProcessId)"}}
    Start-Sleep -Milliseconds 700
    if($exe){try{Start-Process -FilePath $exe | Out-Null;$events+="started-foreground:$exe"}catch{$events+="foreground-start-failed:$($_.Exception.Message)"}}
    Start-Sleep -Seconds 2
    return $events
}
function New-ManagedCommand([string]$Name,[string]$Script,[string]$Args='') {
    if(-not(Test-Path -LiteralPath $Script)){throw "Managed script missing: $Script"}
    $cmd = "powershell -NoProfile -ExecutionPolicy Bypass -File `"$Script`""
    if($Args){$cmd += " $Args"}
    [pscustomobject]@{trigger=$Name;command=$cmd;ground='foreground';voice='';allowParams='false'}
}

if($env:COMPUTERNAME -ine 'MSI'){throw "This repair package is pinned to COMPUTERNAME=MSI; current=$env:COMPUTERNAME"}
if(-not(Test-Path -LiteralPath 'D:\')){throw 'D: is not mounted.'}
Ensure-Dir $ScriptRoot
Ensure-Dir $ReceiptRoot
$state=Get-TriggerState
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$receiptPath=Join-Path $ReceiptRoot "trigger-registry-$stamp.json"

$existing=@();$parseWarning='';$backup='';$changed=$false;$reloadEvents=@()
if(Test-Path -LiteralPath $state.commands){
    try{
        $raw=[System.IO.File]::ReadAllText($state.commands).TrimStart([char]0xFEFF)
        if($raw.Trim()){$existing=@($raw | ConvertFrom-Json)}
    }catch{
        $parseWarning=$_.Exception.Message
        $bad=$state.commands+".bad-$stamp"
        Copy-Item -LiteralPath $state.commands -Destination $bad -Force
        $existing=@()
    }
}

if($ApplyDefaults){
    if(-not $state.registered){throw 'TRIGGERcmd profile is not registered; token.tkn/computerid.cfg missing.'}
    $wanted=@(
        (New-ManagedCommand 'Certa Trigger Refresh' $SelfPath '-ApplyDefaults -Reload'),
        (New-ManagedCommand 'Certa Trigger Registry Status' $SelfPath '-Status'),
        (New-ManagedCommand 'Certa Reviewed Package Apply' $ReviewedPackagePath '-ApplyLatest'),
        (New-ManagedCommand 'Certa Reviewed Package Status' $ReviewedPackagePath '-Status'),
        (New-ManagedCommand 'Certa OpenClaw Install' $OpenClawScript '-Install'),
        (New-ManagedCommand 'Certa OpenClaw Status' $OpenClawScript '-Status')
    )
    $names=@($wanted | ForEach-Object { $_.trigger })
    $merged=@($existing | Where-Object { $names -notcontains [string]$_.trigger }) + $wanted
    Ensure-Dir $state.data_dir
    if(Test-Path -LiteralPath $state.commands){$backup=$state.commands+".bak-$stamp";Copy-Item -LiteralPath $state.commands -Destination $backup -Force}
    $tmp=$state.commands+'.new'
    Write-Utf8NoBom $tmp ($merged | ConvertTo-Json -Depth 8)
    [void]([System.IO.File]::ReadAllText($tmp) | ConvertFrom-Json)
    Move-Item -LiteralPath $tmp -Destination $state.commands -Force
    $changed=$true
    if($Reload){$reloadEvents=@(Restart-TriggerCmd)}
}

$final=Get-TriggerState
$namesOut=@();$hash='';$bom=$false
if(Test-Path -LiteralPath $final.commands){
    $bytes=[System.IO.File]::ReadAllBytes($final.commands)
    $bom=($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $hash=(Get-FileHash -Algorithm SHA256 -LiteralPath $final.commands).Hash
    try{$namesOut=@([System.IO.File]::ReadAllText($final.commands).TrimStart([char]0xFEFF) | ConvertFrom-Json | ForEach-Object {[string]$_.trigger})}catch{}
}
$required=@('Certa Trigger Refresh','Certa Trigger Registry Status','Certa Reviewed Package Apply','Certa Reviewed Package Status','Certa OpenClaw Install','Certa OpenClaw Status')
$missing=@($required | Where-Object { $namesOut -notcontains $_ })
$receipt=[ordered]@{
    schema='certard.trigger-registry.receipt.v2'
    generated_at=(Get-Date).ToUniversalTime().ToString('o')
    computer=$env:COMPUTERNAME
    registered=$final.registered
    commands_path=$final.commands
    commands_sha256=$hash
    bom_present=$bom
    changed=$changed
    backup=$backup
    parse_warning=$parseWarning
    reload_events=$reloadEvents
    service_status=$final.service_status
    processes=$final.processes
    required_triggers=$required
    missing_required_triggers=$missing
    success=($final.registered -and -not $bom -and $missing.Count -eq 0)
}
Write-Utf8NoBom $receiptPath ($receipt | ConvertTo-Json -Depth 10)
Write-Utf8NoBom (Join-Path $ReceiptRoot 'LATEST.json') ($receipt | ConvertTo-Json -Depth 10)
$receipt.mirror_root=Mirror-Receipt $receiptPath
$receipt | ConvertTo-Json -Depth 10
if(-not $receipt.success){exit 1}
